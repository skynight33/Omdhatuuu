# Om Dhatu Tatva — Vercel deployment

This is a static HTML project prepared from the supplied Om Dhatu Tatva HTML file.

## Deploy using GitHub + Vercel
1. Extract this ZIP.
2. Create a new GitHub repository.
3. Upload `index.html` to the repository root.
4. Open https://vercel.com/ and import that GitHub repository.
5. Keep the framework preset as **Other** (or static site if shown).
6. Leave the build command and output directory blank if Vercel allows it, then deploy.

## Important note
The app uses browser-based HTML/CSS/JavaScript and many features work as a static page. The "Find places" feature for places outside the preloaded Delhi list calls Claude's in-app capability (`claude.use`). That capability is not available on a normal Vercel-hosted website without a separate backend/API integration, so that specific feature may not work after deployment. Do not publish any private API key in frontend code.
